import java.util.*;

/**
 * A <code>TabCell</code> contains the methods necessary to manipulate TabCell objects in the game of Freecell.
 * File: TabCell.java
 * Project: 8
 * @author Gillen Beck
 * @author Emily Boyes
 * @author Liz Curtis
 * @author Bancks Holmes
 * @author Rebecca Melkerson
 */

public class TabCell extends AbstractCell{
	
	
	/**
   	 * Constructor method for tableau cells.
	 */
	public TabCell(){
		super(52);
	}
	
	public boolean canAdd(List<Card> addList){
		if (theCell.isEmpty()) return true;
		else {
			Card topCard = theCell.get(theCell.size() - 1);
			int topRank = topCard.getRank();
			Card addCard = addList.get(0);
			int addRank = addCard.getRank();
			
			if ( (! topCard.sameColor(addCard)) && ((topRank - addRank) == 1) ){
				return true;
			}
			else return false;
		}
	}
	
	public boolean canRemove(int index){
		Card topCard = theCell.get(index);
		int theRank = topCard.getRank();
		int theColor = topCard.getColor();
		boolean canRemove = true;
		for (int i = index + 1; i < theCell.size(); i++) {
			if ( (theCell.get(i).getRank() + 1 == theRank) && 
				(theCell.get(i).getColor() != theColor) ){
				theRank = theCell.get(i).getRank();
				theColor = theCell.get(i).getColor();
			}
			else canRemove = false;
		}
		return canRemove;
	}
	
}