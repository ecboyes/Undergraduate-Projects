/**
 * The interface for the ViewInformer strategy.
 * File: ViewInformer.java
 * Project: 8
 * @author Gillen Beck
 * @author Emily Boyes
 * @author Liz Curtis
 * @author Bancks Holmes
 * @author Rebecca Melkerson
 */

public interface ViewInformer {
	/**
	 * Responds to a mouse press in the panel.
	 * @param panel the panel that was pressed.
	 */
	public void panelPressed(AbstractPanel panel);
	
}
