/**
 * Generic main method template for any GUI-based application.
 * Instantiates a model and passes it to a new view.
 * File: GUIApp.java
 * Project: 8
 * @author Gillen Beck
 * @author Emily Boyes
 * @author Liz Curtis
 * @author Bancks Holmes
 * @author Rebecca Melkerson
 *
 */

import javax.swing.JFrame;

/**
 * Generic main method template for any GUI-based application.
 * Instantiates a model and passes it to a new view.
 */
public class GUIApp{

	public static void main(String[] args){
		final FreeCellGame freeCellGame = new FreeCellGame();
		final JFrame view = new MainView(freeCellGame);
		view.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		view.setSize(800, 600);
		view.setVisible(true);
	}
}