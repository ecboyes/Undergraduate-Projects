/**
 * Represents the GUI component for painting tableau.
 * File: TabPanel.java
 * Project: 8
 * @author Gillen Beck
 * @author Emily Boyes
 * @author Liz Curtis
 * @author Bancks Holmes
 * @author Rebecca Melkerson
 * 
 */

import javax.swing.*;
import java.awt.*;

/**
 * Represents the GUI component for painting a tableau.
 */
@SuppressWarnings("serial")
public class TabPanel extends AbstractPanel{

	/**
	 * Constructor to display a panel containing a tableau. 
	 * @param t the TabCell to be displayed. 
	 */
	public TabPanel(Cell t, ViewInformer i){
		super(t, i);
	}

//	/**
//	 * Paints the tableau if it is nonempty, and a yellow wire frame otherwise.
//	 */
// do we need javadoc since this is in AbstractPanel?	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		Icon image;
		if (theCell.isEmpty()){
			image = Card.getBack();
			g.setColor(Color.yellow);
			int x = (getWidth() - image.getIconWidth()) / 2;
			g.drawRect(x, 0, image.getIconWidth(), image.getIconHeight());
		}
		else{
			int i = 0;
			for (Card card : theCell) {
				image = card.getImage();
				int x = (getWidth() - image.getIconWidth()) / 2;
				int y = image.getIconHeight() / 3;
				image.paintIcon(this, g, x, i);
				i += y;
			}
		}
	}
}