/**
 * Represents the GUI component for painting a panel in the game of Freecell.
 * File: AbstractPanel.java
 * Project: 8
 * @author Gillen Beck
 * @author Emily Boyes
 * @author Liz Curtis
 * @author Bancks Holmes
 * @author Rebecca Melkerson
 * 
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Represents the GUI component for painting a panel.
 */
@SuppressWarnings("serial")
public class AbstractPanel extends JPanel{

	protected Cell theCell;
	protected ViewInformer theInformant;
	protected PanelListener theListener = new PanelListener();

	/**
	 * Constructor to display a panel that contains a cell.
	 * @param the cell that will be displayed.
	 */
	public AbstractPanel(Cell c, ViewInformer i){
		setBackground(new Color(0, 155, 44));
		theCell = c;	
		theInformant = i;
		addMouseListener(new PanelListener());
	}

	/**
	 * Paints the cell if it is nonempty. Otherwise, paints a yellow wire frame.
	 */
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		Icon image;
		if (theCell.isEmpty()){
			image = Card.getBack();
			g.setColor(Color.yellow);
			int x = (getWidth() - image.getIconWidth()) / 2;
			g.drawRect(x, 0, image.getIconWidth(), image.getIconHeight());
		}
		else{
			image = theCell.peekTop().getImage();
			int x = (getWidth() - image.getIconWidth()) / 2;
			image.paintIcon(this, g, x, 0);
		}
	}
	
	/**
	 * Returns the cell in the panel.
	 * @return Cell the cell.
	 */
	public Cell getCell() {
		return theCell;
	}
	
	/**
	 * A listener for individual card panels pressed during the game.
	 */
    private class PanelListener extends MouseAdapter {
		public void mousePressed(MouseEvent e) {
			theInformant.panelPressed( (AbstractPanel)(e.getComponent()) );
		}
    }
}