import java.util.*;

/**
 * Represents a the game of FreeCell.
 * File: FreeCellGame.java
 * Project: 8
 * @author Gillen Beck
 * @author Emily Boyes
 * @author Liz Curtis
 * @author Bancks Holmes
 * @author Rebecca Melkerson
 *
 */

public class FreeCellGame{

	private ArrayList<Cell> freeCells;
	private ArrayList<Cell> homeCells;
	private ArrayList<Cell> tableaux;
	private ArrayList<Cell> moveCells = new ArrayList<Cell>();
	private Deck deck;
	private int movesMade;
	private int possibleMoves;
	private int lastMoveCount;
	private Cell lastMoveFromCell;
	private Cell thisMoveFromCell;
	private Cell lastMoveToCell;
	private Cell thisMoveToCell;
	private Card lastMoveToTop;
	private Card thisMoveToTop;

	/**
	 * Constructor that sets up a game of Freecell.
	 * Instantiates a deck and shuffles it. Creates the necessary cells.
	 * Distributes the deck between the Tableau cells.
	 */
	public FreeCellGame(){
		movesMade = 0;
		lastMoveCount = 0;
		tableaux = new ArrayList<Cell>();
		homeCells = new ArrayList<Cell>();
		freeCells = new ArrayList<Cell>();
		for (int i = 0; i < 4; i++) {
			homeCells.add(new HomeCell());
			freeCells.add(new FreeCell());
		}	
		
		for (int i = 0; i < 8; i++) {
			tableaux.add(new TabCell());
		}
		dealToTabs();
		possibleMoves = getPossibleMoves();
	}
	
	/**
	 * Gets the current move count.
	 * @return the integer move count.
	 */
	public int getMoveCount() {
		return movesMade;
	}
	
	
	/**
	 * Increments move count.
	 */
	public void incMoveCount() {
		movesMade++;
	}
	
	/**
	 * Deals cards to the 8 TabCells.
	 */
	public void dealToTabs() {
		deck = new Deck();
		deck.shuffle();
		List<ArrayList<Card>> dealLists = new ArrayList<ArrayList<Card>>();
		for (int i = 0; i < 8; i++) {
			dealLists.add(new ArrayList<Card>());
		}
		for (int i = 0; i < 52; i++) {
			int pile = i % 8;
			Card card = deck.deal();
			card.turn();
			dealLists.get(pile).add(card);
		}
		for (int i = 0; i < 8; i++) {
			tableaux.get(i).add(dealLists.get(i));
		}
	}
	
	/**
	 * Yields the FreeCell at index i in the list freeCells.
	 * @param i the index
	 * @return the FreeCell at index i
	 */
	public Cell getFree(int i) {
		return freeCells.get(i);
	}
	
	/**
	 * Yields the HomeCell at index i in the list homeCells.
	 * @param i the index
	 * @return the HomeCell at index i
	 */
	public Cell getHome(int i) {
		return homeCells.get(i);
	}
	
	/**
	 * Yields the TabCell at index i in the list tableaux.
	 * @param i the index
	 * @return the TabCell at index i
	 */
	public Cell getTab(int i) {
		return tableaux.get(i);
	}
	
	/**
	 * Resets the game of war.
	 */
	public void newGame(){
		for (Cell cell : freeCells) {
			cell.clearCell();
		}
		for (Cell cell : homeCells) {
			cell.clearCell();
		}
		for (Cell cell : tableaux) {
			cell.clearCell();
		}
		dealToTabs();
		movesMade = 0;
	}
	
	/**
	 * Determines if a card can be moved from one cell to another.
	 * @param fromCell the cell that the card is moved from
	 * @param toCell the cell that the card is moved to
	 * @return true if the move is legal, false otherwise
	 */
	public Boolean canMove(Cell fromCell, Cell toCell) {
		if (fromCell == toCell) return false;
		for (int i = 0; i < fromCell.getSize(); i++) {
			if (fromCell.canRemove(i)) {
				if (toCell.canAdd(fromCell.peek(i))) {
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Calculates the number of possible legal moves.
	 * @param fromCell the cell that the card is moved from
	 * @param toCell the cell that the card is moved to
	 * @return n the number of possible moves
	 */
	public int getPossibleMoves() {
		// number of possible moves, initialized to 0
		int n = 0;

		// check for moves from tab to tab, free, or home
		for (Cell fromCell : tableaux){

			for (Cell toCell : homeCells){
				if (canMove(fromCell, toCell)){
					n++;
					//if (n == 1) return false;
				}
			}

			for (Cell toCell : freeCells){
				if (canMove(fromCell, toCell) || canMove(toCell, fromCell)){ 
					n++;
					//if (n > 1) return false;
					moveCells.add(fromCell); 
					moveCells.add(toCell);
				}
			}

			for (Cell toCell : tableaux) {
				if (canMove(fromCell, toCell)) {
					n++;
					//if (n > 1) return false;
					moveCells.add(fromCell); 
					moveCells.add(toCell);
				}
			}
		}
		// check for moves from free to home
		for (Cell fromCell : freeCells) {
			for (Cell toCell : homeCells) {
				if (canMove(fromCell, toCell)) {
					n++;
				}
			}
		}
		return n;
	}
	
	/**
	 * Determines if there are no more moves left, meaning the game is lost.
	 * @return true if the game is lost, false otherwise
	 */
	public Boolean gameLost(){
		System.out.print(possibleMovesString() + "          ");
		System.out.println("Move count: " + movesMade);
		// no possible moves, so game is over
		if (possibleMoves == 0) return true;
		// one possible move, either from free to home, tab to home, or tab to tab
		if (possibleMoves == 1) {
			// move is from free to home or tab to home
			if (moveCells.isEmpty()) return false;
			// move is from tab to tab, so need to investigate the moveCells
			thisMoveToTop = moveCells.get(1).peekTop(); //error
			thisMoveFromCell = moveCells.get(0);
			thisMoveToCell = moveCells.get(1);
			
			if (lastMoveToTop != null // not the first time possibleMoves == 1
					&&thisMoveToTop.sameColor(lastMoveToTop)
					&& thisMoveToTop.sameRank(lastMoveToTop)
					&& thisMoveFromCell == lastMoveToCell
					&& thisMoveToCell == lastMoveFromCell
					&& movesMade == (lastMoveCount + 1)) {
				return true; //GAME OVER
			}
			
			// not sure if this prints the right stuff			
			lastMoveCount = movesMade;
			lastMoveFromCell = thisMoveFromCell;
			lastMoveToCell = thisMoveToCell;
			lastMoveToTop = thisMoveToTop;
			System.out.println("Last move count: " + lastMoveCount);
			System.out.println("This move count: " + movesMade);
			System.out.println("Last move from cell: " + lastMoveFromCell);
		}
		return false;
	}
	
	/**
	 * Reports that the game is won if all cards are in order.
	 * @param c the cell
	 * @return true if all cards are in order, false otherwise
	 */
	public Boolean gameWon() {
		for (Cell c : tableaux) {
			if (! c.inOrder()) return false;
		}
		return true;
	}
	
	/**
	 * Gives a string for how many possible moves there are.
	 * @return String the string representation of how many legal moves there are
	 */
	public String possibleMovesString(){
		String str = "Possible moves to be made: " + getPossibleMoves();
		return str;
	}
	
	/**
	 * Gives a string for how many moves have been made.
	 * @return String the string representation of how many moves have been made
	 */
	public String movesMadeString(){
		String str = "Move count: " + movesMade;
		return str;
	}
}