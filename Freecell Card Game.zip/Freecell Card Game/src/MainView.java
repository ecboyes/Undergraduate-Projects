/**
 * The main window for playing a game of Freecell.
 * File: MainView.java
 * Project: 8
 * @author Gillen Beck
 * @author Emily Boyes
 * @author Liz Curtis
 * @author Bancks Holmes
 * @author Rebecca Melkerson
 *
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * The main window for playing a game of Freecell.
 */
@SuppressWarnings("serial")
public class MainView extends JFrame{
	
	private FreeCellGame freeCellGame;
	protected AbstractPanel fromPanel = null;
	private ViewInformer informant = new AppViewInformer();
    private JTextArea possibleMovesText = new JTextArea();
    private JTextArea movesMadeText = new JTextArea();

    public MainView(FreeCellGame freeCellGame){
    		this.freeCellGame = freeCellGame;
        this.setTitle("The Game of Free Cell");
        
        // the overall window
        Container window = getContentPane();
        
        // the label bar, Free Cells and Home Cells
        JPanel labelPanel = new JPanel();
        window.add(labelPanel, BorderLayout.NORTH);
        labelPanel.setLayout(new GridLayout(1,2));
        labelPanel.add(new JLabel("Free Cells", JLabel.CENTER));
        labelPanel.add(new JLabel("Home Cells", JLabel.CENTER));
        
        // the middle panel where the game action occurs
        JPanel gamePanel = new JPanel();
        window.add(gamePanel, BorderLayout.CENTER);
        GridBagLayout layout = new GridBagLayout();
        GridBagConstraints constraints = new GridBagConstraints();
        gamePanel.setLayout(layout);
        
        constraints.anchor = GridBagConstraints.NORTHWEST;
        constraints.fill = GridBagConstraints.BOTH;
        constraints.weightx = 1;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.gridheight = 1;
        constraints.weighty = 1;
        
        ArrayList<HomeFreePanel> freePanels = new ArrayList<HomeFreePanel>();
        for (int i = 0; i < 4; i++) {
        		freePanels.add(new HomeFreePanel(freeCellGame.getFree(i), informant));
            constraints.gridx = i;
            layout.setConstraints(freePanels.get(i), constraints);
            gamePanel.add(freePanels.get(i));
        }
        
        
        ArrayList<HomeFreePanel> homePanels = new ArrayList<HomeFreePanel>();
        for (int i = 0; i < 4; i++) {
        		homePanels.add(new HomeFreePanel(freeCellGame.getHome(i), informant));
        		constraints.gridx = i + 4;
        		layout.setConstraints(homePanels.get(i), constraints);
        		gamePanel.add(homePanels.get(i));
        }
        
        ArrayList<TabPanel> tabPanels = new ArrayList<TabPanel>();    
        for (int i = 0; i < 8; i++) {
        		tabPanels.add(new TabPanel(freeCellGame.getTab(i), informant));
            constraints.gridx = i;
            constraints.gridy = 1;
            constraints.weighty = 3;
            layout.setConstraints(tabPanels.get(i), constraints);
            gamePanel.add(tabPanels.get(i));
        }
        
        // the button panel
        JPanel buttonPanel = new JPanel();
        window.add(buttonPanel, BorderLayout.SOUTH);
        buttonPanel.setLayout(new GridLayout(1,3));
        
        possibleMovesText.setBackground(getBackground());
        possibleMovesText.setText(freeCellGame.possibleMovesString());
        possibleMovesText.setEditable(false);
        buttonPanel.add(possibleMovesText);
        
        JButton newGameButton = new JButton("New Game");
        buttonPanel.add(newGameButton);
        
        movesMadeText.setBackground(getBackground());
        movesMadeText.setText(freeCellGame.movesMadeString());
        movesMadeText.setEditable(false);
        buttonPanel.add(movesMadeText);
        
        
        
        newGameButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            		freeCellGame.newGame();
            		for (HomeFreePanel panel : freePanels) {
            			panel.repaint();
            		}
            		for (HomeFreePanel panel : homePanels) {
            			panel.repaint();
            		}
            		for (TabPanel panel : tabPanels) {
            			panel.repaint();
            		}
                possibleMovesText.setText(freeCellGame.possibleMovesString());
                movesMadeText.setText(freeCellGame.movesMadeString());
            }
        });
    }
    
    private class AppViewInformer implements ViewInformer {
    		public void panelPressed(AbstractPanel panel) {
    			// no fromPanel yet, this panel becomes fromPanel
    			if (fromPanel == null) {
    				fromPanel = panel;
    			}
    			// fromPanel and this panel are same, so do nothing
    			else if (fromPanel == panel) {
    				fromPanel = null;
    			}
    			// fromPanel and this panel are different, so attempt a move
    			else {
    				Cell fromCell = fromPanel.getCell();
    				Cell toCell = panel.getCell();
    				for (int i = 0; i < fromCell.getSize(); i++) {
    					if (fromCell.canRemove(i)) {
    						if (toCell.canAdd(fromCell.peek(i))) {
    							toCell.add(fromCell.remove(i));
    							panel.repaint();
    							fromPanel.repaint();
    							freeCellGame.incMoveCount();
    		        				// after cards have been moved, check for loser/winner
    		        				if (freeCellGame.gameLost()) {
    		        					// game lost pop up
    		        					JOptionPane.showMessageDialog(MainView.this,
    		            					"No more moves. \nGame Over.",
    		                 	        "Message",                        
    		                 	        JOptionPane.INFORMATION_MESSAGE);
    		        				}
    							break;
    						}
    					}
    					if (i == fromCell.getSize() - 1) {
    	    					// illegal move pop up
    	            			JOptionPane.showMessageDialog(MainView.this,
    	            					"Illegal Move",
    	                 	       "Message",                        
    	                 	       JOptionPane.INFORMATION_MESSAGE);
    					}
    				}
                possibleMovesText.setText(freeCellGame.possibleMovesString());
                movesMadeText.setText(freeCellGame.movesMadeString());
    				// reset fromPanel to null after move attempt
    				fromPanel = null;

        			if (freeCellGame.gameWon()) {
    					// game won pop up
            			JOptionPane.showMessageDialog(MainView.this,
            					"Game won.",
                 	        "Message",                        
                 	        JOptionPane.INFORMATION_MESSAGE);        				
        			}
    			}
    		}
    }
}