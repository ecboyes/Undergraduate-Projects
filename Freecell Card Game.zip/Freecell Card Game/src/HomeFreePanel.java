/**
 * Represents the GUI component for painting a free or home cell.
 * File: HomeFreePanel.java
 * Project: 8
 * @author Gillen Beck
 * @author Emily Boyes
 * @author Liz Curtis
 * @author Bancks Holmes
 * @author Rebecca Melkerson
 * 
 */

/**
 * Represents the GUI component for painting a free or home cell.
 */
@SuppressWarnings("serial")
public class HomeFreePanel extends AbstractPanel{

	/**
	 * Constructor to display a FreePanel and HomePanel.
	 * @param c the Cell to display.
	 */
	public HomeFreePanel(Cell c, ViewInformer i){
		super(c, i);
	}
}