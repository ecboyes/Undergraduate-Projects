import java.util.*;

/**
 * This interface is for the cells in the game of Freecell.
 * There are methods for canAdd, add, canRemove, remove, toString,
 * isEmpty, cellFull, clearCell, getSize, getGard, peekTop, and inOrder.
 * File: Cell.java
 * Project: 8
 * @author Gillen Beck
 * @author Emily Boyes
 * @author Liz Curtis
 * @author Bancks Holmes
 * @author Rebecca Melkerson
 */

public interface Cell extends Iterable<Card>{
	
	/**
	 * Checks if list to be added and cell fit the cell type's rules for adding.
	 * @param addList list to be added
	 * @return true if add can be done, false if otherwise
	 */
	public boolean canAdd(List<Card> addList);
	
	
	/**
	 * Adds a list of Cards to the cell.
	 * Precondition: canAdd returns true.
	 * @param addList list to be added
	 * @return true if add happened, false otherwise
	 */
	public boolean add(List<Card> addList);

	
	/**
	 * Checks if the cards from index to the end of the cell fit the cell type's rules for removal.
	 * @param index index in list to remove down from
	 * @return true if remove can be done, false if otherwise
	 */
	public boolean canRemove(int index);
	
	
	/**
	 * Removes a list of Cards from given index to end of list.
	 * Precondition: canRemove returns true
	 * @param index index from list to remove down from
	 * @return List of cards removed, null if nothing removed
	 */
	public List<Card> remove(int index);

	
    /**
     * Determines if the theCell is empty.
     * @return true if the theCell contains no cards, false otherwise
     */
	public boolean isEmpty();
	
    /**
     * Determines if the theCell is full.
     * @return true if theCell is full, false otherwise
     */
	public boolean cellFull();
	
	/**
	 * Clears the cell of its cards.
	 */
	public void clearCell();
	
	/**
	 * Gives the size of the cell.
	 * @return the size (length) of the cell
	 */
	public int getSize();
	
	/**
	 * Returns the card at the top of the cell (visually, the bottom most card).
	 * @return Card the card
	 */
	public Card peekTop();
	
	/**
	 * Returns and integer for the index of a card.
	 * @param index
	 * @return the index of a card, an integer
	 */
	public List<Card> peek(int index);
	
	/**
	 * Determines if the cards are in descending order, alternating red and black.
	 * @return true if the cards are in descending order with alternating colors, false otherwise
	 */
	public boolean inOrder();
}