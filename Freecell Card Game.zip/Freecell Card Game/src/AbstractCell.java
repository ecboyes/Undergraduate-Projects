import java.util.*;

/**
 * An <code>AbstractCell</code> contains abstract methods canAdd, and canRemove, with 
 * implemented methods add, remove, and toString for objects that implement the Cell Interface. 
 * File: AbstractCell.java
 * Project: 8
 * @author Gillen Beck
 * @author Emily Boyes
 * @author Liz Curtis
 * @author Bancks Holmes
 * @author Rebecca Melkerson
 */

public abstract class AbstractCell implements Cell{
	
	protected List<Card> theCell;
	private int maxSize;
	
	protected AbstractCell(int size){
		maxSize = size;
		theCell = new ArrayList<Card>();
	}
	
	abstract public boolean canAdd(List<Card> addList);
	
	abstract public boolean canRemove(int index);
	
	public boolean add(List<Card> addList){
		if (this.canAdd(addList)){
			theCell.addAll(addList);
			return true;
		}
		return false;
	}

	public List<Card> remove(int index){
		if (this.canRemove(index)){
			List<Card> removeList = new ArrayList<Card>();
			for (int i = index; i < theCell.size(); i++){
				removeList.add(theCell.get(i));
			}
			for (int i = theCell.size() - 1; i >= index; i--){
				theCell.remove(i);
			}
			return removeList;
		}
		else return null;
	}
	
	//does this need a javadoc?
	public String toString(){
		String str = "";
		for (Card i : theCell) str += (i + " ");
		return str;
	}
	
	public boolean isEmpty(){
		return (theCell.size() == 0);
	}

	public boolean cellFull(){
		if (theCell.size() == maxSize) return true;
		else return false;
	}
	
	//javadoc?
	public Iterator<Card> iterator(){
		Iterator<Card> cellIterator = theCell.iterator();
		return cellIterator;
	}
	
	public void clearCell() {
		theCell.clear();
	}
	
	public int getSize() {
		return theCell.size();
	}
	
	//javadoc?
	public Card getCard(int i) {
		return theCell.get(i);
	}
	
	public Card peekTop() {
		return getCard(getSize() - 1);
	}
	
	public List<Card> peek(int index){
		List<Card> peekList = new ArrayList<Card>();
		for (int i = index; i < theCell.size(); i++) {
			peekList.add(theCell.get(i));
		}
		return peekList;
 	}

	public boolean inOrder() {
		if (getSize() <= 1) return true;
		else {
			for (int i = 0; i < getSize() - 1; i++) {
				if (getCard(i).getRank() < getCard(i + 1).getRank()) return false;
			}
			return true;
		}
	}
}