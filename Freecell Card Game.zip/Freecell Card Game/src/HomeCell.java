import java.util.*;

/**
 * A <code>HomeCell</code> contains the methods necessary to manipulate HomeCell objects in the game of Freecell.
 * File: HomeCell.java
 * Project: 8
 * @author Gillen Beck
 * @author Emily Boyes
 * @author Liz Curtis
 * @author Bancks Holmes
 * @author Rebecca Melkerson
 */

public class HomeCell extends AbstractCell{
	
	
    /**
     * Constructor method for HomeCells.
     */
	public HomeCell(){
		super(13);
	}
	
	public boolean canAdd(List<Card> addList){
        //Phase 1: homeCell is empty
		if (theCell.size() == 0) {
			Card addCard = addList.get(0);
			int addRank = addCard.getRank();

			if (addList.size() > 2) return false;
			if (theCell.isEmpty() && addRank == 1) return true;
			else return false;
			}
		
		//Phase 2: homeCell already contains at least one card
		Card topCard = theCell.get(theCell.size() - 1);
		int topRank = topCard.getRank();
		Card addCard = addList.get(0);
		int addRank = addCard.getRank();
		
		if (addList.size() > 2) return false;
		if (topCard.sameSuit(addCard) && (addRank - topRank) == 1) return true;
		else return false;
		
	}

	public boolean canRemove(int index){
		return false;
	}
	
}