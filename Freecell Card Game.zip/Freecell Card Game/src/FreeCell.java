import java.util.*;

/**
 * A <code>FreeCell</code> contains the methods necessary to manipulate FreeCell objects in the game of Freecell.
 * File: FreeCell.java
 * Project: 8
 * @author Gillen Beck
 * @author Emily Boyes
 * @author Liz Curtis
 * @author Bancks Holmes
 * @author Rebecca Melkerson
 */

public class FreeCell extends AbstractCell{
	
	/**
    	 * Constructor method for FreeCells.
	 */
	public FreeCell(){
		super(1);
	}
	
	public boolean canAdd(List<Card> addList) {
		if (theCell.isEmpty() && addList.size() < 2) return true;
		else return false;
	}
	
	public boolean canRemove(int index) {
		if (this.isEmpty()) return false;
		else return true;
	}
	
}